import {
  StatusPill,
} from "../../components/StatusPill";
import type {
  TwinResponse,
} from "../../types/twin";
import {
  formatValue,
  riskColor,
} from "../../utils";

const unavailable = "—";


function dimensionLabel(
  key: string,
) {
  return key
    .replace(
      /_m$/,
      " (m)",
    )
    .replaceAll(
      "_",
      " ",
    );
}


function dimensionValue(
  value: unknown,
) {
  if (
    typeof value ===
    "number"
  ) {
    return Number.isInteger(
      value,
    )
      ? value.toString()
      : value.toFixed(2);
  }

  return String(
    value,
  ).replaceAll(
    "_",
    " ",
  );
}


function scoreValue(
  value?:
    | number
    | null,
) {
  return value != null ? (
    <>
      {value.toFixed(0)}
      <small>/100</small>
    </>
  ) : (
    unavailable
  );
}


function healthClass(
  value?:
    | number
    | null,
) {
  if (value == null) {
    return "UNAVAILABLE";
  }

  if (value >= 85) {
    return "EXCELLENT";
  }

  if (value >= 70) {
    return "GOOD";
  }

  if (value >= 55) {
    return "MONITOR";
  }

  if (value >= 40) {
    return "POOR";
  }

  return "CRITICAL";
}


export function TwinPanels({
  twin,
}: {
  twin: TwinResponse;
}) {
  const dimensions =
    Object.entries(
      twin.twin
        .dimensions,
    ).filter(
      ([key]) =>
        key !==
        "representation",
    );

  const health =
    healthClass(
      twin.ai
        .health_score,
    );

  const methodLabel =
    twin.ai
      .model_validated
      ? "Locally validated model"
      : "SIMRAS research prediction";

  return (
    <div className="twin-panels">
      <section className="panel score-panel score-panel-four">
        <div>
          <span>
            SIMRAS predicted health
          </span>

          <strong>
            {scoreValue(
              twin.ai
                .health_score,
            )}
          </strong>

          <small>
            {health}
          </small>
        </div>

        <div>
          <span>
            SIMRAS risk score
          </span>

          <strong
            style={{
              color:
                riskColor(
                  twin.ai
                    .risk_level,
                ),
            }}
          >
            {scoreValue(
              twin.ai
                .risk_score,
            )}
          </strong>

          <small>
            {twin.ai
              .risk_level ??
              unavailable}
          </small>
        </div>

        <div>
          <span>
            Environmental hazard
          </span>

          <strong
            style={{
              color:
                riskColor(
                  twin.ai
                    .hazard_level,
                ),
            }}
          >
            {scoreValue(
              twin.ai
                .hazard_score,
            )}
          </strong>

          <small>
            {twin.ai
              .hazard_level ??
              "NO HAZARD INPUT"}
          </small>
        </div>

        <div>
          <span>
            Prediction confidence
          </span>

          <strong>
            {twin.ai
              .confidence !=
            null
              ? `${Math.round(
                  twin.ai
                    .confidence *
                    100,
                )}%`
              : unavailable}
          </strong>

          <small>
            Data completeness + source confidence
          </small>
        </div>
      </section>

      <section className="panel prediction-disclosure">
        <div>
          <span>
            Prediction layer
          </span>

          <strong>
            {methodLabel}
          </strong>
        </div>

        <div>
          <span>Engine</span>

          <strong>
            {twin.ai
              .prediction_method ??
              "Not available"}
          </strong>
        </div>

        <div>
          <span>Version</span>

          <strong>
            {
              twin.ai
                .model_version
            }
          </strong>
        </div>

        <StatusPill
          label={
            twin.ai
              .model_validated
              ? "VALIDATED"
              : twin.ai.status
          }
          tone={
            twin.ai
              .model_validated
              ? "good"
              : "warn"
          }
        />
      </section>

      <section className="panel">
        <header>
          <h3>
            SIMRAS recommendations
          </h3>

          <StatusPill
            label="HUMAN REVIEW REQUIRED"
            tone="warn"
          />
        </header>

        <ul className="factor-list">
          {(twin.ai
            .recommendations ??
            []).map(
            (
              recommendation,
            ) => (
              <li
                key={
                  recommendation
                }
              >
                {
                  recommendation
                }
              </li>
            ),
          )}
        </ul>
      </section>

      <section className="panel">
        <header>
          <h3>
            Why this prediction?
          </h3>

          <StatusPill
            label={
              twin.ai.status
            }
            tone="warn"
          />
        </header>

        <ul className="factor-list">
          {twin.ai
            .factors.map(
              (factor) => (
                <li
                  key={
                    factor
                  }
                >
                  {factor}
                </li>
              ),
            )}
        </ul>
      </section>

      <section className="panel">
        <header>
          <h3>
            Government environment
          </h3>

          <StatusPill
            label={
              twin.freshness
                .environment
            }
          />
        </header>

        <div className="metric-grid">
          {Object.entries(
            twin.environment,
          ).map(
            ([
              key,
              item,
            ]) => (
              <article
                key={key}
              >
                <span>
                  {key.replaceAll(
                    "_",
                    " ",
                  )}
                </span>

                <strong>
                  {formatValue(
                    item.value,
                    item.unit,
                  )}
                </strong>

                <small>
                  {item.source_type.replaceAll(
                    "_",
                    " ",
                  )}
                  {" · "}
                  {
                    item.source
                  }
                </small>

                <small>
                  {item.quality_flag.replaceAll(
                    "_",
                    " ",
                  )}
                  {item.confidence !=
                  null
                    ? ` · ${Math.round(
                        item.confidence *
                          100,
                      )}% confidence`
                    : ""}
                </small>
              </article>
            ),
          )}

          {Object.keys(
            twin.environment,
          ).length === 0 && (
            <p>
              No matched government environmental feed.
            </p>
          )}
        </div>
      </section>

      <section className="panel provenance-panel">
        <header>
          <h3>
            Digital twin & provenance
          </h3>

          <StatusPill
            label={
              twin.asset
                .identity_status
            }
            tone={
              twin.asset
                .identity_status ===
              "VERIFIED"
                ? "good"
                : "warn"
            }
          />
        </header>

        <dl>
          <div>
            <dt>
              3D fidelity
            </dt>

            <dd>
              {
                twin.twin
                  .fidelity_level
              }
              {" · "}
              {
                twin.twin
                  .model_source
              }
            </dd>
          </div>

          <div>
            <dt>
              Model source
            </dt>

            <dd>
              {twin.twin
                .source_url ? (
                <a
                  className="model-source-link"
                  href={
                    twin.twin
                      .source_url
                  }
                  target="_blank"
                  rel="noreferrer"
                >
                  Published source ↗
                </a>
              ) : (
                "Procedural illustration"
              )}
            </dd>
          </div>

          <div>
            <dt>
              Structural sensors
            </dt>

            <dd>
              {twin.sensors_status.replaceAll(
                "_",
                " ",
              )}
            </dd>
          </div>

          <div>
            <dt>
              Inspection
            </dt>

            <dd>
              {twin.inspection.quality_flag.replaceAll(
                "_",
                " ",
              )}
            </dd>
          </div>

          <div>
            <dt>RUL</dt>

            <dd>
              Disabled until longitudinal AP validation
            </dd>
          </div>
        </dl>

        {dimensions.length >
          0 && (
          <div className="dimension-list">
            <h4>
              Twin dimensions
            </h4>

            <dl>
              {dimensions.map(
                ([
                  key,
                  value,
                ]) => (
                  <div
                    key={
                      key
                    }
                  >
                    <dt>
                      {dimensionLabel(
                        key,
                      )}
                    </dt>

                    <dd>
                      {dimensionValue(
                        value,
                      )}
                    </dd>
                  </div>
                ),
              )}
            </dl>
          </div>
        )}
      </section>
    </div>
  );
}
