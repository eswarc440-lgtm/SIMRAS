import type { TwinResponse } from "../../types/twin";

type Props = {
  twin: TwinResponse;
  colour: string;
  showDimensions: boolean;
};

function numberValue(
  dimensions: Record<string, unknown>,
  keys: string[],
  fallback: number,
): number {
  for (const key of keys) {
    const value = dimensions[key];

    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
  }

  return fallback;
}

function scaled(
  value: number,
  reference: number,
  minimum: number,
  maximum: number,
) {
  return Math.max(
    minimum,
    Math.min(maximum, value / reference),
  );
}

function BridgeModel({
  twin,
  colour,
}: Props) {
  const dimensions =
    twin.twin.dimensions;

  const length = numberValue(
    dimensions,
    ["length_m"],
    120,
  );

  const width = numberValue(
    dimensions,
    ["deck_width_m", "width_m"],
    10,
  );

  const pierHeight = numberValue(
    dimensions,
    ["pier_height_m", "height_m"],
    12,
  );

  const spanCount = Math.max(
    2,
    Math.min(
      8,
      Math.round(
        numberValue(
          dimensions,
          ["span_count"],
          3,
        ),
      ),
    ),
  );

  const sceneLength = scaled(
    length,
    10,
    8,
    18,
  );

  const sceneWidth = scaled(
    width,
    4,
    2.2,
    4.5,
  );

  const sceneHeight = scaled(
    pierHeight,
    5,
    2,
    4,
  );

  const pierPositions =
    Array.from(
      {
        length:
          spanCount - 1,
      },
      (_, index) =>
        -sceneLength / 2 +
        ((index + 1) *
          sceneLength) /
          spanCount,
    );

  return (
    <group>
      <mesh
        position={[0, 1.45, 0]}
        castShadow
        receiveShadow
      >
        <boxGeometry
          args={[
            sceneLength,
            0.55,
            sceneWidth,
          ]}
        />
        <meshStandardMaterial
          color={colour}
          metalness={0.2}
          roughness={0.72}
        />
      </mesh>

      {pierPositions.map(
        (x) => (
          <mesh
            key={x}
            position={[
              x,
              -0.25,
              0,
            ]}
            castShadow
            receiveShadow
          >
            <boxGeometry
              args={[
                0.5,
                sceneHeight,
                sceneWidth *
                  0.72,
              ]}
            />
            <meshStandardMaterial
              color="#7d8b96"
              roughness={0.9}
            />
          </mesh>
        ),
      )}

      <mesh
        position={[
          0,
          1.82,
          sceneWidth / 2 -
            0.16,
        ]}
      >
        <boxGeometry
          args={[
            sceneLength,
            0.12,
            0.12,
          ]}
        />
        <meshStandardMaterial
          color="#d9e2e8"
          metalness={0.45}
        />
      </mesh>

      <mesh
        position={[
          0,
          1.82,
          -sceneWidth / 2 +
            0.16,
        ]}
      >
        <boxGeometry
          args={[
            sceneLength,
            0.12,
            0.12,
          ]}
        />
        <meshStandardMaterial
          color="#d9e2e8"
          metalness={0.45}
        />
      </mesh>

      <mesh
        position={[
          0,
          -1.42,
          0,
        ]}
        rotation={[
          -Math.PI / 2,
          0,
          0,
        ]}
        receiveShadow
      >
        <planeGeometry
          args={[24, 10]}
        />
        <meshStandardMaterial
          color="#0b5d78"
          transparent
          opacity={0.55}
        />
      </mesh>
    </group>
  );
}

function DamModel({
  twin,
  colour,
}: Props) {
  const dimensions =
    twin.twin.dimensions;

  const length = numberValue(
    dimensions,
    ["length_m"],
    300,
  );

  const height = numberValue(
    dimensions,
    ["height_m"],
    28,
  );

  const crestWidth =
    numberValue(
      dimensions,
      [
        "crest_width_m",
        "width_m",
      ],
      8,
    );

  const sceneLength = scaled(
    length,
    22,
    9,
    18,
  );

  const sceneHeight = scaled(
    height,
    10,
    2.7,
    5.2,
  );

  const sceneWidth = scaled(
    crestWidth,
    3,
    1.6,
    3.2,
  );

  return (
    <group>
      <mesh
        position={[
          0,
          0.15,
          0,
        ]}
        rotation={[
          0,
          0,
          -0.06,
        ]}
        castShadow
        receiveShadow
      >
        <boxGeometry
          args={[
            sceneLength,
            sceneHeight,
            sceneWidth,
          ]}
        />

        <meshStandardMaterial
          color={colour}
          roughness={0.82}
        />
      </mesh>

      <mesh
        position={[
          0,
          sceneHeight / 2 +
            0.25,
          0,
        ]}
        castShadow
      >
        <boxGeometry
          args={[
            sceneLength,
            0.28,
            sceneWidth *
              0.65,
          ]}
        />

        <meshStandardMaterial
          color="#d7dde2"
          roughness={0.72}
        />
      </mesh>

      <mesh
        position={[
          0,
          -1.35,
          -(
            sceneWidth / 2 +
            3.3
          ),
        ]}
        rotation={[
          -Math.PI / 2,
          0,
          0,
        ]}
        receiveShadow
      >
        <planeGeometry
          args={[22, 7]}
        />

        <meshStandardMaterial
          color="#0b6c8c"
          transparent
          opacity={0.62}
        />
      </mesh>

      {[
        -2.2,
        -0.75,
        0.75,
        2.2,
      ].map((x) => (
        <mesh
          key={x}
          position={[
            x,
            0.2,
            sceneWidth / 2 +
              0.18,
          ]}
          castShadow
        >
          <boxGeometry
            args={[
              0.48,
              sceneHeight *
                0.72,
              0.38,
            ]}
          />

          <meshStandardMaterial
            color="#707c84"
          />
        </mesh>
      ))}
    </group>
  );
}

function BarrageModel({
  twin,
  colour,
}: Props) {
  const dimensions =
    twin.twin.dimensions;

  const length = numberValue(
    dimensions,
    ["length_m"],
    240,
  );

  const gateCount = Math.max(
    5,
    Math.min(
      18,
      Math.round(
        numberValue(
          dimensions,
          ["gate_count"],
          10,
        ),
      ),
    ),
  );

  const sceneLength = scaled(
    length,
    18,
    10,
    19,
  );

  const gateSpacing =
    sceneLength / gateCount;

  return (
    <group>
      <mesh
        position={[
          0,
          -0.7,
          0,
        ]}
        castShadow
        receiveShadow
      >
        <boxGeometry
          args={[
            sceneLength,
            0.65,
            2.4,
          ]}
        />

        <meshStandardMaterial
          color={colour}
          roughness={0.8}
        />
      </mesh>

      {Array.from(
        {
          length:
            gateCount + 1,
        },
        (_, index) => {
          const x =
            -sceneLength / 2 +
            index *
              gateSpacing;

          return (
            <mesh
              key={index}
              position={[
                x,
                0.55,
                0,
              ]}
              castShadow
            >
              <boxGeometry
                args={[
                  0.28,
                  3.1,
                  2.7,
                ]}
              />

              <meshStandardMaterial
                color="#818b91"
              />
            </mesh>
          );
        },
      )}

      {Array.from(
        {
          length:
            gateCount,
        },
        (_, index) => {
          const x =
            -sceneLength / 2 +
            (index + 0.5) *
              gateSpacing;

          return (
            <mesh
              key={`gate-${index}`}
              position={[
                x,
                0.35,
                0,
              ]}
            >
              <boxGeometry
                args={[
                  gateSpacing *
                    0.72,
                  2.1,
                  0.22,
                ]}
              />

              <meshStandardMaterial
                color="#4d7b8d"
                metalness={0.3}
              />
            </mesh>
          );
        },
      )}

      <mesh
        position={[
          0,
          -1.4,
          -2.7,
        ]}
        rotation={[
          -Math.PI / 2,
          0,
          0,
        ]}
        receiveShadow
      >
        <planeGeometry
          args={[24, 7]}
        />

        <meshStandardMaterial
          color="#0a6b8a"
          transparent
          opacity={0.62}
        />
      </mesh>
    </group>
  );
}

function GenericModel({
  colour,
}: {
  colour: string;
}) {
  return (
    <group>
      <mesh
        castShadow
        receiveShadow
      >
        <boxGeometry
          args={[8, 3, 5]}
        />

        <meshStandardMaterial
          color={colour}
          roughness={0.75}
        />
      </mesh>
    </group>
  );
}

export function AssetSpecificModel(
  props: Props,
) {
  const type =
    props.twin.asset
      .asset_type;

  if (type === "bridge") {
    return (
      <BridgeModel
        {...props}
      />
    );
  }

  if (type === "dam") {
    return (
      <DamModel
        {...props}
      />
    );
  }

  if (type === "barrage") {
    return (
      <BarrageModel
        {...props}
      />
    );
  }

  return (
    <GenericModel
      colour={props.colour}
    />
  );
}
