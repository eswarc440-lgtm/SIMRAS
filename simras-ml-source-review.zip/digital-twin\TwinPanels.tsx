import { StatusPill } from "../../components/StatusPill";
import type { TwinResponse } from "../../types/twin";
import { formatValue, riskColor } from "../../utils";

const unavailable = "\u2014";

function dimensionLabel(key: string) {
  return key.replace(/_m$/, " (m)").replaceAll("_", " ");
}

function dimensionValue(value: unknown) {
  if (typeof value === "number") {
    return Number.isInteger(value) ? value.toString() : value.toFixed(2);
  }
  return String(value).replaceAll("_", " ");
}

function scoreValue(value?: number | null) {
  return value != null ? (
    <>
      {value.toFixed(0)}
      <small>/100</small>
    </>
  ) : (
    unavailable
  );
}

export function TwinPanels({ twin }: { twin: TwinResponse }) {
  const dimensions = Object.entries(twin.twin.dimensions).filter(
    ([key]) => key !== "representation",
  );
  const methodLabel = twin.ai.model_validated
    ? "Validated ML model"
    : twin.ai.status === "DECISION_SUPPORT"
      ? "Engineering estimate - ML validation pending"
      : "ML prediction unavailable";

  return (
    <div className="twin-panels">
      <section className="panel score-panel score-panel-four">
        <div>
          <span>Health</span>
          <strong>{scoreValue(twin.ai.health_score)}</strong>
        </div>
        <div>
          <span>Structural risk</span>
          <strong style={{ color: riskColor(twin.ai.risk_level) }}>
            {scoreValue(twin.ai.risk_score)}
          </strong>
        </div>
        <div>
          <span>Environment hazard</span>
          <strong style={{ color: riskColor(twin.ai.hazard_level) }}>
            {scoreValue(twin.ai.hazard_score)}
          </strong>
        </div>
        <div>
          <span>Confidence</span>
          <strong>
            {twin.ai.confidence != null
              ? `${Math.round(twin.ai.confidence * 100)}%`
              : unavailable}
          </strong>
        </div>
      </section>

      <section className="panel prediction-disclosure">
        <div>
          <span>Prediction method</span>
          <strong>{methodLabel}</strong>
        </div>
        <div>
          <span>Engine</span>
          <strong>{twin.ai.prediction_method ?? "Not available"}</strong>
        </div>
        <div>
          <span>Version</span>
          <strong>{twin.ai.model_version}</strong>
        </div>
        <StatusPill
          label={twin.ai.model_validated ? "VALIDATED" : twin.ai.status}
          tone={twin.ai.model_validated ? "good" : "warn"}
        />
      </section>

      <section className="panel">
        <header>
          <h3>Current environment</h3>
          <StatusPill label={twin.freshness.environment} />
        </header>
        <div className="metric-grid">
          {Object.entries(twin.environment).map(([key, item]) => (
            <article key={key}>
              <span>{key.replaceAll("_", " ")}</span>
              <strong>{formatValue(item.value, item.unit)}</strong>
              <small>
                {item.source_type.replaceAll("_", " ")}
                {" \u00b7 "}
                {item.source}
              </small>
            </article>
          ))}
          {Object.keys(twin.environment).length === 0 && (
            <p>No environmental feed is matched.</p>
          )}
        </div>
      </section>

      <section className="panel">
        <header>
          <h3>Decision-support factors</h3>
          <StatusPill label={twin.ai.status} tone="warn" />
        </header>
        <ul className="factor-list">
          {twin.ai.factors.map((factor) => (
            <li key={factor}>{factor}</li>
          ))}
        </ul>
      </section>

      <section className="panel provenance-panel">
        <header>
          <h3>Reality & provenance</h3>
          <StatusPill
            label={twin.asset.identity_status}
            tone={twin.asset.identity_status === "VERIFIED" ? "good" : "warn"}
          />
        </header>
        <dl>
          <div>
            <dt>3D fidelity</dt>
            <dd>
              {twin.twin.fidelity_level}
              {" \u00b7 "}
              {twin.twin.model_source}
            </dd>
          </div>
          <div>
            <dt>Model source</dt>
            <dd>
              {twin.twin.source_url ? (
                <a
                  className="model-source-link"
                  href={twin.twin.source_url}
                  target="_blank"
                  rel="noreferrer"
                >
                  Published engineering source {"\u2197"}
                </a>
              ) : (
                "Not available"
              )}
            </dd>
          </div>
          <div>
            <dt>Structural sensors</dt>
            <dd>{twin.sensors_status.replaceAll("_", " ")}</dd>
          </div>
          <div>
            <dt>Inspection</dt>
            <dd>{twin.inspection.quality_flag.replaceAll("_", " ")}</dd>
          </div>
          <div>
            <dt>RUL</dt>
            <dd>
              {twin.ai.remaining_life_years ??
                "Disabled until longitudinal validation"}
            </dd>
          </div>
        </dl>

        {dimensions.length > 0 && (
          <div className="dimension-list">
            <h4>Published model dimensions</h4>
            <dl>
              {dimensions.map(([key, value]) => (
                <div key={key}>
                  <dt>{dimensionLabel(key)}</dt>
                  <dd>{dimensionValue(value)}</dd>
                </div>
              ))}
            </dl>
          </div>
        )}
      </section>
    </div>
  );
}